import React from 'react';
import NavBar from './NavBar';

const Header = () => {
    console.log("Header component rendered");
    return (
        <NavBar />
    );
}

export default Header;