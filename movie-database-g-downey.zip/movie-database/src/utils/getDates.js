function getYear(){
    const d = new Date();
    return d.getFullYear();
}

export { getYear }